//Creating the map --------
const theMap = L.map("myMap").setView([0, 0], 1);
const attribution =
  '&copy <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
const tileUrl = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const tiles = L.tileLayer(tileUrl, { attribution });
tiles.addTo(theMap);

theMap.setMaxBounds(theMap.getBounds());
//Creating map ends --------

//Define variables --------
const api = "http://api.openweathermap.org/data/2.5/forecast?zip=";
const myKey = "&appid=(YOUR-API-KEY)=metric";

//Define variables ends --------


document
  .getElementById("generate")
  .addEventListener("click", async function () {
    //Define Date
    let d = new Date();
    let newDate = d.getMonth()+ 1 + "." + d.getDate() + "." + d.getFullYear();

    //Get zip & feelings values from user
    const zipValue = document.getElementById("zip").value;
    const userFeelings = document.getElementById("feelings").value;
    
    //Fetch Data from API-----------------

    //Get Data from an API
    async function fetchWeather(api, zipValue, myKey) {
      const response = await fetch(api + zipValue + myKey); //Store fetched data in a variable
      const intoJSON = await response.json(); //Change data form into JSON
    //Store required sub-Data in variables
      const cityName = intoJSON.city.name;
      const lat = intoJSON.city.coord.lat;
      const lon = intoJSON.city.coord.lon;
      const temp = intoJSON.list[0].main.temp;
    //Adjusting Map
      L.marker([lat, lon]).addTo(theMap);
      theMap.setView([lat, lon], 3);
    //Add variables to the HTML
      document.getElementById("name").textContent = cityName;
      document.getElementById("lat").textContent = lat;
      document.getElementById("lon").textContent = lon;
      document.getElementById("temperature").textContent = (temp).toFixed(2);

    //Defining POST data
      const data = { cityName, lat, lon, temp, userFeelings, newDate };//Select data to be sent to Server
    //Create the method required to make a post
      const defineMethod = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      };
      //Making a POST
      //Send data to server /api to be stored in request
      const res = await fetch("/api", defineMethod); //Store server /api response in a variable
      const receivedData = await res.json(); //Change response in JSON

      console.log(receivedData);
      //Add sub-Data to HTML
      document.getElementById("cityName").innerHTML =
        "City Name: " + receivedData.cityName;
      document.getElementById("date").innerHTML = "Date: " + receivedData.date;
      document.getElementById("temp").innerHTML =
        "Temperature " + receivedData.temp + "°C";
      document.getElementById("content").innerHTML =
        "Feelings: " + receivedData.feel;
    }
    //Calling the function
    fetchWeather(api, zipValue, myKey);
  });
