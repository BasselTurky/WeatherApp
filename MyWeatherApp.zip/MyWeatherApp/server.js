const express = require('express');
const app = express();

const bodyParser = require("body-parser");
/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require("cors");
app.use(cors());

app.listen(3000, () => console.log('Server running on port 3000'));
app.use(express.static('website'));
app.use(express.json({limit: '1mb'}));

projectData = {}

app.get('/all',(req,res)=>{
    res.send(projectData)
    projectData = {}
})


//post function

app.post('/api', addData);

function addData(request, response) {

let data = request.body;

console.log('server side data ', data)

//date
//temp -> temperature
// feelings -> user's input

projectData["date"] = data.newDate;
projectData["temp"] = data.temp;
projectData["feel"] = data.userFeelings;
projectData["latitude"] = data.lat;
projectData["longitude"] = data.lon;
projectData["cityName"] = data.cityName;

response.send(projectData);
}

